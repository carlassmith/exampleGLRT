/*!
 * \file definitions.h
 * \author <your name>
 * \date April 20, 2012
 * \brief  If you are defining any constants they better be in this file and only this file.
 */

#ifndef DEFINITIONS_H
#define DEFINITIONS_H
#include <cuda_runtime.h>

#define pi 3.141592f;

void CUDAERROR(const char *instr,int lineNumber);
void cudasafe( cudaError_t err, char* str, int lineNumber);

#endif