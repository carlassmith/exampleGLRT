/* sample usage
  a = int32(randi(1000,1000,1))';
  b = int32(randi(1000,1000,1))';
  c = mexfilename(a,b);
*/

#include <windows.h>
#pragma comment(lib, "kernel32.lib")

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mex.h>
#include <cuda_runtime.h>
#include "definitions.h"

#ifndef max
//! not defined in the C standard used by visual studio
#define max(a,b) (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
//! not defined in the C standard used by visual studio
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

//******************************************************
// extern C declarations of the kernels from wrapper.cu.  Yes you can put this in a
// header if you want.
extern void kernel_example_wrapper(dim3 dimGrid, dim3 dimBlock, int* c, const int* a, const int*b);

//*******************************************************************************************
void CUDAERROR(const char *instr,int lineNumber) {
	cudaError_t errornum;
	const char *str;
	if (errornum=cudaGetLastError()) {
		//reset all cuda devices
		int deviceCount = 0;
		int ii = 0;
		cudasafe(cudaGetDeviceCount(&deviceCount),"cudaGetDeviceCount",__LINE__ ); //query number of GPUs
		for (ii = 0; ii< deviceCount;ii++) {
			cudaSetDevice(ii);
			cudaDeviceReset();
		}
		str=cudaGetErrorString(errornum);
		//mexPrintf("gpuGaussNDmle(line %i): %s in %s\n",lineNumber, str, instr);
		cudaDeviceReset();
		mexErrMsgIdAndTxt("mexFunction:cudaFail","gpuGaussNDmle(line %i): %s in %s\n",lineNumber, str, instr);
		exit(1); // might not stop matlab
	}
}

//*******************************************************************************************
void cudasafe( cudaError_t err, char* str, int lineNumber)
{
	if (err != cudaSuccess)
	{
		//reset all cuda devices
		int deviceCount = 0;
		int ii = 0;
		cudasafe(cudaGetDeviceCount(&deviceCount),"cudaGetDeviceCount",__LINE__ ); //query number of GPUs
		for (ii = 0; ii< deviceCount;ii++) {
			cudaSetDevice(ii);
			cudaDeviceReset();
		}
		mexErrMsgIdAndTxt("mexFunction:cudaFail","%s failed with error code %i at line %d\n",str,err, lineNumber);
		exit(1); // might not stop matlab
	}
}


//*******************************************************************************************
void mexFunction(int nlhs, mxArray *plhs[],	int	nrhs, const	mxArray	*prhs[]) {
/*!
 *  \brief Entry point in the code for Matlab.  Equivalent to main().
 *  \param nlhs number of left hand mxArrays to return
 *  \param plhs array of pointers to the output mxArrays
 *  \param nrhs number of input mxArrays
 *  \param prhs array of pointers to the input mxArrays.
 */
	//declare all vars
	int *array_a=0, *array_b=0; 
	int *d_a=0, *d_b=0, *d_c=0;
	const mwSize *array_a_size=0,*array_b_size=0;
	size_t Ndim_a=0, Ndim_b=0;

	//check for required inputs, correct types, and dimensions
	if (nrhs != 2)
		mexErrMsgIdAndTxt("CUDAtemplate:WrongNumberInputs","Input must include vectors a,b");

	if (mxGetClassID(prhs[0])!=mxINT32_CLASS)
		mexErrMsgIdAndTxt("CUDAtemplate:WrongType","Inputs must be 32 bit ints");
	
	Ndim_a = mxGetNumberOfDimensions(prhs[0]);
	Ndim_b = mxGetNumberOfDimensions(prhs[1]);
	array_a_size = mxGetDimensions(prhs[0]);
	array_b_size = mxGetDimensions(prhs[1]);

	//1D vectors still return 2D
	if (Ndim_a > 2 || Ndim_b > 2 || array_a_size[0] > 1 || array_b_size[0] > 1)
		mexErrMsgIdAndTxt("CUDAtemplate:WrongDimensions","a and b should be 1D vectors");

	if (array_a_size[1] != array_b_size[1])
		mexErrMsgIdAndTxt("CUDAtemplate:VectorMismatch","size of a != b");
	//retrieve all inputs
	array_a = (int*) mxGetData(prhs[0]);
	array_b = (int*) mxGetData(prhs[1]);

	//validate input values(this section better not be blank!)

	//query GPUs
	int deviceCount=0;
	int driverVersion=0;
	int runtimeVersion=0;
	cudasafe(cudaDriverGetVersion(&driverVersion),"Could not query CUDA driver version",__LINE__);
	cudasafe(cudaRuntimeGetVersion(&runtimeVersion),"Could not query CUDA runtime version",__LINE__);
	cudasafe(cudaGetDeviceCount(&deviceCount),"Error detecting CUDA devices",__LINE__);
	if (deviceCount < 1)
		mexErrMsgIdAndTxt("GPUgaussMLEv2:NoDevice","No CUDA capable devices were detected");

	cudaDeviceProp deviceProp; 
	cudasafe(cudaGetDeviceProperties(&deviceProp, 0),"Could not get properties for device 0.",__LINE__);
	cudasafe(cudaSetDevice(0),"Could not select GPU 0.",__LINE__);
	mexPrintf("Using GPU %s\n",deviceProp.name);
	if (deviceProp.kernelExecTimeoutEnabled)
		mexWarnMsgTxt("Warning, Kernel Execution Timeout is enabled for the GPU you are using.\nIf your fitting takes longer than the timeout it will fail.");

	//allocate memory and shove data on the GPU
	dim3 dimBlock((unsigned int) array_a_size[1]);
    dim3 dimGrid(1);
	const size_t bytes = array_a_size[1]*sizeof(float);
	cudasafe(cudaMalloc((void**)&d_a, bytes), "malloc d_a",__LINE__);
	cudasafe(cudaMalloc((void**)&d_b, bytes), "malloc d_b",__LINE__);
	cudasafe(cudaMalloc((void**)&d_c, bytes), "malloc d_c",__LINE__);
	cudasafe(cudaMemcpy(d_a, array_a, bytes, cudaMemcpyHostToDevice), "copy a to d_a", __LINE__);
	cudasafe(cudaMemcpy(d_b, array_b, bytes, cudaMemcpyHostToDevice), "copy b to d_b", __LINE__);

	//kernel calls
	kernel_example_wrapper(dimGrid,dimBlock,d_c,d_a,d_b);
	CUDAERROR("example kernel",__LINE__);

	//allocate results memory and copy results back to matlab
	plhs[0] = mxCreateNumericMatrix(array_a_size[0],array_a_size[1],mxINT32_CLASS, mxREAL);
	cudasafe(cudaMemcpy((int*)mxGetData(plhs[0]), d_c, bytes, cudaMemcpyDeviceToHost), "copy d_c to return value", __LINE__);

	//clean up!
	cudasafe(cudaFree(d_a),"freeing d_a",__LINE__);
	cudasafe(cudaFree(d_b),"freeing d_b",__LINE__);
	cudasafe(cudaFree(d_c),"freeing d_c",__LINE__);
	cudaDeviceReset(); //release context so future cudaSetDevice calls work

	return;
 }